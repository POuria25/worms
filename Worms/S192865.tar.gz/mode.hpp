#ifndef MODE_HPP__
#define MODE_HPP__

enum Mode
{
    AIMING,
    WALKING,
    SHOOTING,
    FIRING
};

#endif
#include "gameobject.hpp"

GameObject::~GameObject() = default;
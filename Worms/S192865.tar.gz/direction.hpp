#ifndef DIRECTION_HPP__
#define DIRECTION_HPP__

enum Direction
{
    UP,
    DOWN,
    LEFT,
    RIGHT,
    NONE
};

#endif